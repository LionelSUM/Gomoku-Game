
module Gomoku {
	requires java.desktop;
	requires java.sql;
}